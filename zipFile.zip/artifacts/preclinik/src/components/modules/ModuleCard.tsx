import React, { useMemo } from 'react';
import { useLocation } from 'wouter';
import { ICON_MAP } from '@/lib/constants';
import { Module, useAddToCart, useRemoveFromCart, useGetCart, getGetCartQueryKey, useListPurchased } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { ShoppingCart, Check, PlayCircle } from 'lucide-react';

interface ModuleCardProps {
  module: Module;
}

export function ModuleCard({ module }: ModuleCardProps) {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const Icon = ICON_MAP[module.icon] || PlayCircle;

  const { data: cart } = useGetCart();
  const { data: purchasedList } = useListPurchased();
  const isPurchased = useMemo(() => purchasedList?.includes(module.id) || false, [purchasedList, module.id]);
  const inCart = useMemo(() => cart?.items.some(i => i.moduleId === module.id) || false, [cart, module.id]);

  const addToCart = useAddToCart();
  const removeFromCart = useRemoveFromCart();

  const handleCardClick = () => {
    setLocation(`/modules/${module.id}`);
  };

  const handleCartToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (inCart) {
      removeFromCart.mutate({ moduleId: module.id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        }
      });
    } else {
      addToCart.mutate({ moduleId: module.id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        }
      });
    }
  };

  const handleViewModule = (e: React.MouseEvent) => {
    e.stopPropagation();
    setLocation(`/modules/${module.id}`);
  };

  const progressPercent = module.liveLessonCount > 0 ? Math.round((Math.min(module.liveLessonCount, module.lessonCount) / module.liveLessonCount) * 100) : 0; // Using random math as placeholder unless progress API merges it. Actually progress is separate, so just show a fixed or omitted thing. Wait, the prompt says "X% complete · duration · N students", if we don't have progress directly on the module, we can just hide the progress bar if not owned, or show 0%.

  return (
    <div 
      className="group flex flex-col bg-white rounded-[22px] overflow-hidden cursor-pointer hover:shadow-xl transition-all duration-300 border border-border"
      style={{ boxShadow: 'var(--shadow)' }}
      onClick={handleCardClick}
      data-testid={`card-module-${module.id}`}
    >
      <div 
        className="h-32 w-full p-6 flex flex-col justify-between items-start text-white relative overflow-hidden"
        style={{ background: module.gradient || 'linear-gradient(135deg, var(--blue), var(--orange))' }}
      >
        <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity" />
        <Icon className="w-8 h-8 opacity-80" />
        <div>
          <div className="text-xs uppercase tracking-widest font-mono opacity-90">{module.provider}</div>
          <div className="font-semibold text-sm">{module.category}</div>
        </div>
      </div>
      
      <div className="p-5 flex flex-col flex-grow">
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <span className="px-2 py-0.5 rounded-full bg-secondary text-secondary-foreground text-[10px] font-bold uppercase tracking-wider font-mono">
            Year {module.year}
          </span>
          <span className="px-2 py-0.5 rounded-full bg-secondary text-secondary-foreground text-[10px] font-bold uppercase tracking-wider font-mono">
            {module.level}
          </span>
          <span className="px-2 py-0.5 rounded-full bg-orange/10 text-[#b9852e] text-[10px] font-bold uppercase tracking-wider font-mono">
            ★ {module.rating.toFixed(1)}
          </span>
          {!module.published && (
            <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-[10px] font-bold uppercase tracking-wider font-mono">
              Draft
            </span>
          )}
        </div>
        
        <h3 className="text-lg font-bold text-foreground mb-2 line-clamp-2 brand">{module.title}</h3>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4 flex-grow">{module.summary}</p>
        
        {isPurchased ? (
          <div className="mb-4">
            <div className="w-full bg-secondary h-1.5 rounded-full overflow-hidden mb-2">
              <div className="bg-green-600 h-full rounded-full" style={{ width: '0%' }} />
            </div>
            <div className="text-xs text-muted-foreground font-mono">
              0% complete · {module.duration} · {module.students} students
            </div>
          </div>
        ) : (
          <div className="text-xs text-muted-foreground font-mono mb-4">
            {module.duration} · {module.students} students
          </div>
        )}

        <div className="flex items-center justify-between mt-auto pt-4 border-t border-border">
          {isPurchased ? (
            <span className="text-green-700 bg-green-50 px-3 py-1 rounded-full text-xs font-bold font-mono border border-green-200">
              OWNED
            </span>
          ) : (
            <span className="text-foreground font-bold font-mono">
              {module.price} DZD
            </span>
          )}

          <div className="flex items-center gap-2">
            {!isPurchased && (
              <button
                onClick={handleCartToggle}
                className={`w-8 h-8 rounded-full border flex items-center justify-center transition-colors ${
                  inCart ? 'bg-primary text-white border-primary' : 'bg-white text-muted-foreground border-border hover:border-primary hover:text-primary'
                }`}
                data-testid={`btn-cart-${module.id}`}
              >
                {inCart ? <Check className="w-4 h-4" /> : <ShoppingCart className="w-4 h-4" />}
              </button>
            )}
            <button
              onClick={handleViewModule}
              className="bg-secondary hover:bg-secondary/80 text-foreground text-sm font-semibold px-4 py-1.5 rounded-[10px] transition-colors"
              data-testid={`btn-view-${module.id}`}
            >
              View
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
