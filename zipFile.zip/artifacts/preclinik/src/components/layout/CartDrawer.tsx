import React from 'react';
import { X, ShoppingCart, Trash2 } from 'lucide-react';
import { useGetCart, useRemoveFromCart, useCheckout, getGetCartQueryKey, getListPurchasedQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

interface CartDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CartDrawer({ open, onOpenChange }: CartDrawerProps) {
  const { data: cart } = useGetCart();
  const removeFromCart = useRemoveFromCart();
  const checkout = useCheckout();
  const queryClient = useQueryClient();

  if (!open) return null;

  const handleRemove = (moduleId: string) => {
    removeFromCart.mutate({ moduleId }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
      }
    });
  };

  const handleCheckout = () => {
    checkout.mutate(undefined, {
      onSuccess: () => {
        toast.success("Purchase complete — added to your library", {
          style: { background: 'var(--surface)', color: 'var(--ink)', border: '1px solid var(--border)' }
        });
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListPurchasedQueryKey() });
        onOpenChange(false);
      }
    });
  };

  return (
    <>
      <div 
        className="fixed inset-0 bg-black/40 z-50 backdrop-blur-sm transition-opacity"
        onClick={() => onOpenChange(false)}
      />
      <div className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-white shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-300 border-l border-border">
        <div className="p-6 border-b border-border flex items-center justify-between bg-secondary/30">
          <div className="flex items-center gap-3">
            <ShoppingCart className="w-5 h-5 text-primary" />
            <h2 className="font-serif text-xl font-bold">Your Cart</h2>
          </div>
          <button 
            onClick={() => onOpenChange(false)}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-secondary text-muted-foreground transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {!cart?.items || cart.items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center text-muted-foreground">
              <ShoppingCart className="w-12 h-12 mb-4 opacity-20" />
              <p className="font-mono text-sm">Your cart is empty.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {cart.items.map((item) => (
                <div key={item.moduleId} className="flex gap-4 p-4 rounded-2xl border border-border bg-white shadow-sm">
                  <div className="flex-1 min-w-0">
                    <div className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground font-mono mb-1">
                      {item.category}
                    </div>
                    <h4 className="font-bold text-sm text-foreground truncate">{item.title}</h4>
                    <div className="text-xs text-muted-foreground font-mono mt-1">
                      {item.duration}
                    </div>
                    <div className="font-bold font-mono mt-2 text-primary">
                      {item.price} DZD
                    </div>
                  </div>
                  <button 
                    onClick={() => handleRemove(item.moduleId)}
                    className="self-start p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {cart && cart.items.length > 0 && (
          <div className="p-6 border-t border-border bg-secondary/30">
            <div className="flex items-center justify-between mb-6">
              <span className="font-mono text-sm font-bold text-muted-foreground uppercase tracking-widest">Total</span>
              <span className="font-serif text-2xl font-bold">{cart.total} DZD</span>
            </div>
            <button
              onClick={handleCheckout}
              disabled={checkout.isPending}
              className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-[10px] shadow-lg shadow-primary/20 transition-all flex items-center justify-center gap-2"
            >
              {checkout.isPending ? 'Processing...' : 'Secure Checkout'}
            </button>
          </div>
        )}
      </div>
    </>
  );
}
