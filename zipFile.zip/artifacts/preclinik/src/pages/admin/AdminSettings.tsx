import React from 'react';
import { Settings, Shield, Bell, Database } from 'lucide-react';

export default function AdminSettings() {
  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-4xl">
      <div>
        <h1 className="text-3xl font-serif font-bold text-foreground mb-2">Platform Settings</h1>
        <p className="text-muted-foreground">Configure application preferences and defaults.</p>
      </div>

      <div className="bg-white rounded-[22px] border border-border shadow-sm overflow-hidden divide-y divide-border">
        
        <div className="p-8 flex flex-col md:flex-row gap-8">
          <div className="w-full md:w-1/3">
            <div className="flex items-center gap-2 mb-2 text-foreground font-bold">
              <Settings className="w-4 h-4 text-primary" />
              General
            </div>
            <p className="text-sm text-muted-foreground">Basic platform information and localization.</p>
          </div>
          <div className="w-full md:w-2/3 space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-muted-foreground font-mono uppercase tracking-widest">Platform Name</label>
              <input type="text" defaultValue="PreClinik" className="w-full h-12 px-4 rounded-xl border border-border bg-background focus:bg-white focus:ring-2 focus:ring-primary outline-none transition-all font-bold" />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-muted-foreground font-mono uppercase tracking-widest">Support Email</label>
              <input type="email" defaultValue="support@preclinik.dz" className="w-full h-12 px-4 rounded-xl border border-border bg-background focus:bg-white focus:ring-2 focus:ring-primary outline-none transition-all" />
            </div>
          </div>
        </div>

        <div className="p-8 flex flex-col md:flex-row gap-8">
          <div className="w-full md:w-1/3">
            <div className="flex items-center gap-2 mb-2 text-foreground font-bold">
              <Database className="w-4 h-4 text-primary" />
              Currency & Pricing
            </div>
            <p className="text-sm text-muted-foreground">Default currency and payment settings.</p>
          </div>
          <div className="w-full md:w-2/3 space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-muted-foreground font-mono uppercase tracking-widest">Default Currency</label>
              <select className="w-full h-12 px-4 rounded-xl border border-border bg-background focus:bg-white focus:ring-2 focus:ring-primary outline-none transition-all font-bold">
                <option value="DZD">DZD (Algerian Dinar)</option>
                <option value="EUR">EUR (Euro)</option>
              </select>
            </div>
          </div>
        </div>

        <div className="p-8 flex flex-col md:flex-row gap-8">
          <div className="w-full md:w-1/3">
            <div className="flex items-center gap-2 mb-2 text-foreground font-bold">
              <Shield className="w-4 h-4 text-primary" />
              Access Control
            </div>
            <p className="text-sm text-muted-foreground">Manage registration and permissions.</p>
          </div>
          <div className="w-full md:w-2/3 space-y-4">
            <label className="flex items-center gap-3 p-4 border border-border rounded-xl cursor-pointer hover:bg-secondary/30 transition-colors">
              <input type="checkbox" defaultChecked className="w-5 h-5 rounded text-primary border-border focus:ring-primary" />
              <div>
                <div className="font-bold text-sm">Allow new student registrations</div>
                <div className="text-xs text-muted-foreground font-mono">Anyone can create an account</div>
              </div>
            </label>
          </div>
        </div>

        <div className="p-8 bg-secondary/30 flex justify-end">
          <button className="bg-primary hover:bg-primary/90 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-primary/20 transition-all">
            Save Settings
          </button>
        </div>

      </div>
    </div>
  );
}
