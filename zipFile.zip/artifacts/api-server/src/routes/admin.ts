import { Router, type IRouter } from "express";
import { db, modulesTable, lessonsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/admin/stats", async (_req, res): Promise<void> => {
  const [moduleStats] = await db
    .select({
      totalModules: sql<number>`count(*)::int`,
      liveModules: sql<number>`count(*) filter (where ${modulesTable.published} = true)::int`,
      totalStudents: sql<number>`coalesce(sum(${modulesTable.students}), 0)::int`,
    })
    .from(modulesTable);

  const [lessonStats] = await db
    .select({
      totalLessons: sql<number>`count(*)::int`,
      liveLessons: sql<number>`count(*) filter (where ${lessonsTable.published} = true)::int`,
    })
    .from(lessonsTable);

  res.json({
    totalModules: Number(moduleStats?.totalModules ?? 0),
    liveModules: Number(moduleStats?.liveModules ?? 0),
    totalLessons: Number(lessonStats?.totalLessons ?? 0),
    liveLessons: Number(lessonStats?.liveLessons ?? 0),
    totalStudents: Number(moduleStats?.totalStudents ?? 0),
  });
});

// Static student data (will become real once auth is implemented)
router.get("/admin/students", async (_req, res): Promise<void> => {
  const students = [
    { id: "s1", name: "Meriem Saadi", email: "meriem.saadi@example.com", progressPercent: 72 },
    { id: "s2", name: "Anis Benali", email: "anis.benali@example.com", progressPercent: 45 },
    { id: "s3", name: "Lina Khelifi", email: "lina.khelifi@example.com", progressPercent: 88 },
    { id: "s4", name: "Karim Ouali", email: "karim.ouali@example.com", progressPercent: 31 },
    { id: "s5", name: "Sara Boudaoud", email: "sara.boudaoud@example.com", progressPercent: 60 },
  ];
  res.json(students);
});

export default router;
