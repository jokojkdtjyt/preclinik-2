import { pgTable, text, timestamp, primaryKey } from "drizzle-orm/pg-core";

export const cartTable = pgTable("cart", {
  userId: text("user_id").notNull(),
  moduleId: text("module_id").notNull(),
}, (t) => [primaryKey({ columns: [t.userId, t.moduleId] })]);

export const purchasedTable = pgTable("purchased", {
  userId: text("user_id").notNull(),
  moduleId: text("module_id").notNull(),
  purchasedAt: timestamp("purchased_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.userId, t.moduleId] })]);
